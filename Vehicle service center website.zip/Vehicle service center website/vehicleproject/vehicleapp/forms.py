from django import forms
from .models import servicecenter,services

class centerform(forms.ModelForm):
    class Meta:
        model = servicecenter
        fields = "__all__"
    
class serviceform(forms.ModelForm):
    class Meta:
        model = services
        fields="__all__"