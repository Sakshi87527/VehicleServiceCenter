from django.shortcuts import render,redirect
from .models import admin, user,servicecenter,s_center,services,cart,ServiceBooking, order,payment
from .forms import centerform,serviceform
from django.views.generic import CreateView,ListView,DeleteView,UpdateView,DetailView
from django.db.models import Q
from django.http import HttpResponse
from django.urls import reverse_lazy
from django.contrib.auth.hashers import make_password,check_password
from django.core.mail import EmailMessage
import datetime
import random,string
# Create your views here.

def index(request):
    return render(request,'nav.html')
def thankyou(request):
    return render(request,'contactusthankyou.html')
    
def homepage(request):
    usersession = request.session['username']
    customerobj =  user.objects.get(email=usersession)
    return render(request,"homepage.html",{'session':customerobj.firstname})

def contactus(request):
    if request.method == "GET":
        return render(request,"contactus.html")
    elif request.method =="POST":
        usersession = request.session['username']
        customerobj = user.objects.get(email=usersession)
    return render(request,"contactusthankyou.html",{'session':customerobj.firstname})
def aboutus(request):
    usersession = request.session['username']
    customerobj = user.objects.get(email=usersession)
    return render(request,"aboutus.html",{'session':customerobj.firstname})

def vehicledetail(request):
    return render(request,'servicedetail.html')

def adminregisteration(request):
    if request.method == "GET":
        return render(request,"adminregister.html")
    elif request.method=="POST":
        firstname=request.POST.get("firstname")
        lastname=request.POST.get("lastname")
        email=request.POST.get("email")
        password=request.POST.get("pass")
        gender=request.POST.get("gender")
        password = make_password(password) #encrypted password
        customerobj=admin(firstname=firstname,lastname=lastname,email=email,password=password,gender=gender)
        customerobj.save()

        #return HttpResponse("Customer registration Successfully")
        return redirect('../adminlogin/')
def adminlogin(request):
    if request.method=="GET":
        return render(request,"adminlogin.html")
    elif request.method=="POST":
        cust= admin.objects.filter(email = request.POST["email"]) # filter method to check multiple records 

        if cust:

            custobj= admin.objects.get(email=request.POST.get("email"))
            passfe= request.POST.get("pass") #frontend password fetch
            flag = check_password(passfe,custobj.password) #nonencrypted password 1st argument custobj database mai se fetch krte hai oh 2nd argument that is encrypted password
          
            if flag:
                
                request.session['admin']=request.POST.get("email")#session kb create hoga jb flag ki username password correct hogi tb
                session= request.session['admin']

                return redirect('../admincenter/')
                #return render(request,"homepage.html",{'session':session })
               
                #session = request.session['username']
         
            else:
                return HttpResponse("Wrong Username or password")
            
   


def userregisteration(request):
    if request.method == "GET":
        return render(request,"registration.html")
    elif request.method=="POST":
        firstname=request.POST.get("firstname")
        lastname=request.POST.get("lastname")
        email=request.POST.get("email")
        password=request.POST.get("pass")
        gender=request.POST.get("gender")
        password = make_password(password) #encrypted password
        customerobj=user(firstname=firstname,lastname=lastname,email=email,password=password,gender=gender)
        customerobj.save()

        #return HttpResponse("Customer registration Successfully")
        #send_mail.send()

        return redirect('../userlogin/')
def userlogin(request):
    if request.method=="GET":
        return render(request,"loginform.html")
    elif request.method=="POST":
        cust= user.objects.filter(email = request.POST["email"]) # filter method to check multiple records 

        if cust:

            custobj= user.objects.get(email=request.POST.get("email"))
            passfe= request.POST.get("pass") #frontend password fetch
            flag = check_password(passfe,custobj.password) #nonencrypted password 1st argument custobj database mai se fetch krte hai oh 2nd argument that is encrypted password
          
            if flag:
                
                request.session['username']=request.POST.get("email")#session kb create hoga jb flag ki username password correct hogi tb
                session= request.session['username']

                return redirect('../homepage/')
                #return render(request,"homepage.html",{'session':session })
               
                #session = request.session['username']
         
            else:
                return HttpResponse("Wrong Username or password")
                

def logout(request):
    request.session['username']=''
    # del(request.session['username'] )
    return redirect('../userlogin/')
class createview(CreateView):
    model = servicecenter
    form_class = centerform 
    template_name = "servicecenterform.html"
    success_url = reverse_lazy("center")

   

class show(ListView):
    model = servicecenter
    template_name = "servicecentershow.html"
    context_object_name = "center"
   


class CenterListView(ListView):
    model = s_center
    template_name = "homepage.html"
    context_object_name = "centerobj"

    def get_context_data(self,**kwargs):
        if 'username' in self.request.session:
            data = self.request.session['username']
            obj = user.objects.get(email=data)
            # obj = admin.objects.get(email=data)
            context = super().get_context_data(**kwargs)
            context['session']=obj.firstname

            return context
        elif 'admin' in self.request.session:
            data = self.request.session['admin']
            obj = admin.objects.get(email=data)
            context = super().get_context_data(**kwargs)
            context['session']=obj.firstname

            return context

def search(request):
    if request.method == "POST":
        usersession = request.session['username']
        customerobj =  user.objects.get(email=usersession)
        sq = request.POST.get('searchquery')
        print(sq)
        result = s_center.vehicles.filter(Q(center_name__icontains=sq)|Q(city__icontains=sq)|Q(state__icontains=sq)) #custommanager object is pets (it is inherited custommanager class)
        if result:
            return render(request,"homepage.html",{'centerobj':result,'session':customerobj.firstname})
        else:  
            return HttpResponse("No Result Found")

def searchcar(request):
    if request.method == "POST":
        usersession = request.session['username']
        customerobj =  user.objects.get(email=usersession)


        car_name = request.POST.get('carmodel')
        record = services.objects.filter(Q(select_car__icontains=car_name) )

        return render(request, 'servicedetail.html', {'services': record,'session':customerobj.firstname})
      
   
class ServiceListView(DetailView):
    model = services
    template_name = "servicedetail.html"
    context_object_name = "services"

    def get_context_data(self,**kwargs):
        data = self.request.session['username']
        obj = user.objects.get(email=data)
        context = super().get_context_data(**kwargs)
        context['session']=obj.firstname

        return context
    
def servicess(request):
    if request.method=="GET":
        return render(request,"services.html")
    elif request.method=="POST":
        usersession = request.session['admin']
        customerobj =  admin.objects.get(email=usersession)
        service_center = s_center.vehicles.get(owner_id=customerobj.id)
        
        select_car = request.POST.get("select_car")
        service_category = request.POST.get("service_category")
        price = request.POST.get("price")
        package_name = request.POST.get("package_name")
        photo = request.FILES['photo']
        description= request.POST.get("description")
        
        serviceobj = services(select_car=select_car,service_category=service_category,price=price,package_name=package_name,photo=photo,description=description,sc_id_id=service_center.id)
        serviceobj.save()

        return render(request,"services.html")
    
def center_services(request,id):
    usersession = request.session['username']
    customerobj =  user.objects.get(email=usersession)
    service_center = s_center.vehicles.get(id=id)
    serv = services.objects.filter(sc_id_id=service_center)
    return render(request,'servicedetail.html',{'service_centers': service_center, 'services': serv,'session':customerobj.firstname})
def addservices(request):
    service_id = request.POST['sid']
    sobj = services.objects.get(id=service_id)
    usersession = request.session['username']
    cobj = user.objects.get(email=usersession)

    cart_items = cart.objects.filter(customer_id=cobj.id)

    for item in cart_items:
        if item.sc_id_id != sobj.sc_id.id:
            return HttpResponse("You have already added services from another service center. If you want to select services from a new service center, please delete the current service center details.")

    cartobj = cart(service_id_id=service_id, customer_id_id=cobj.id, totalprice=sobj.price, sc_id_id=sobj.sc_id.id)
    cartobj.save()
    cartobjdisplay = cart.objects.filter(customer_id=cobj.id)
    service_center = s_center.vehicles.get(id=sobj.sc_id.id)
    vcart = services.objects.filter(sc_id_id=service_center.id)

    return render(request, "cart.html", {'session': cobj.firstname, 'services': cartobjdisplay, 'service_centers': service_center, 'carts': vcart})
   
def viewcart(request):
    usersession = request.session['username']
    customerobj =  user.objects.get(email=usersession)
    cartobj = cart.objects.filter(customer_id = customerobj.id)
   
    return render(request,'cart.html',{'services':cartobj,'session':customerobj.firstname})
def deletecart(request):
    if request.method=="POST":
        id = request.POST['deletecart']
        print(id)
        cartobj = cart.objects.get(id=id)
        print(cartobj)
        cartobj.delete()
        return redirect('../viewcart/')
    else:
        return render(request,'cart.html')

def summarypage(request):
        usersession = request.session['username']
        customerobj =  user.objects.get(email=usersession)
        cartobj = cart.objects.filter(customer_id = customerobj.id)
        totalbill = 0;
        for i in cartobj:
            totalbill=i.totalprice+totalbill
        print(type(cartobj))
        return render(request,"summary.html",{'session':customerobj.firstname,'cartobj':cartobj,'totalbill':totalbill})

def admincenter(request):
    if request.method=="GET":
        adminobj = request.session["admin"]
        customerobj =  admin.objects.get(email=adminobj)
        centerobj = s_center.vehicles.filter(owner_id=customerobj.id)
        return render(request,"admincenter.html",{'session':customerobj.firstname,'centerobj':centerobj})
    elif request.method=="POST":
        adminsession = request.session['admin']
        customerobj =  admin.objects.get(email=adminsession)

        center_name = request.POST.get("center_name")
        city = request.POST.get("city")
        state = request.POST.get("state")
        phone = request.POST.get("phone")
        image = request.FILES['image']

        centerobj = s_center(center_name=center_name,city=city,state=state,phone=phone,image=image)
        centerobj.save()
        return render (request,'admincenter.html',{'session':customerobj.firstname,'centerobj':centerobj})
    


def adminservice(request):
    if request.method=="GET":
        adminobj = request.session["admin"]
        adminobj =  admin.objects.get(email=adminobj)
        serviceobj = s_center.vehicles.get(owner_id=adminobj.id)
        serobj = services.objects.filter(sc_id_id= serviceobj.id)
        return render(request,"adminpage.html",{'session':adminobj.firstname,'serviceobj':serviceobj,'serobj':serobj})
    elif request.method=="POST":
        adminsession = request.session['admin']
        adminobj =  admin.objects.get(email=adminsession)
    
        select_car = request.POST.get("select_car")
        service_category = request.POST.get("service_category")
        price = request.POST.get("price")
        package_name = request.POST.get("package_name")
        photo = request.FILES['photo']
        description= request.POST.get("description")
        
        serviceobj = services(select_car=select_car,service_category=service_category,price=price,package_name=package_name,photo=photo,description=description)
        serviceobj.save()
    
    return render(request,'adminpage.html',{'session':adminobj.firstname,'serviceobj':serviceobj})
def update(request,id):
    serviceobj=services.objects.get(id=id)
    serviceobj.service_category =request.POST['service_category']
    serviceobj.price = request.POST['price']
    serviceobj.description=request.POST['description']
    serviceobj.save()
    return redirect("/adminservice") 
def edit(request,id):
    
    serviceobj = services.objects.get(id=id)
    return render(request,"edit.html",{'service':serviceobj})              

def delete(request,id):
    serviceobj=services.objects.get(id=id)
    serviceobj.delete()
    return redirect("/adminservice")              

def s_profile(request):
    if request.method=="GET":
        adminobj = request.session["admin"]
        return render(request,"servicecenterdetail.html",{'session':adminobj})
    elif request.method=="POST":
        adminsession = request.session['admin']
        ownerobj =  admin.objects.get(email=adminsession)
    
        name = request.POST.get("name")
        phone = request.POST.get("phone")
        email = request.POST.get("email")
        centername = request.POST.get("center_name")
        state = request.POST.get("state")
        city = request.POST.get("city")
        centeraddress = request.POST.get("center_add")
        centerphone = request.POST.get("center_phone")
        image = request.FILES['image']
        
        profileobj = s_center(name=name,phone=phone,email=email,center_name=centername,state=state,city=city,center_add=centeraddress,center_phone=centerphone,image=image,owner_id = ownerobj.id)
        profileobj.save()
        return redirect('../service/')
def payments(request):
    usersession = request.session['username']
    customerobj = user.objects.get(email=usersession)
    cartobj = cart.objects.filter(customerid = customerobj.id)
    totalbill = 0

    for i in cartobj:
        totalbill1 = i.totalprice + totalbill1

    advnce= totalbill1*0.3
    
    print(type(cartobj))
    

    orderobj = ServiceBooking.objects.filter()
    return render(request,"payment.html",{'session':customerobj.firstname,'cartobj':cartobj,'totalbill': totalbill})

def booking(request):
    if request.method=="GET":
        return render(request,"servicebooking.html")
    elif request.method=="POST":
        usersession = request.session['username']
        customerobj =  user.objects.get(email=usersession)
        
        # serv = services.objects.get(id=id)
        # sid= serv.sc_id.id
        # print(sid)
        # service_center = center1.vehicles.get(id=sid)
        cartobj= cart.objects.filter(customer_id_id= customerobj.id)
        name1 = request.POST.get("name")
        phone1 = request.POST.get("phone")
        email1 = request.POST.get("email")
        vehicleModel = request.POST.get("vehicle_model")
        vehicle_number = request.POST.get("vehicle_number")
        serviceDate = request.POST.get("service_date")
        timeSlot = request.POST.get("time_slot")
        additionalInfo = request.POST.get("additional_info")

        string.ascii_letters=  'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        a= random.choice(string.ascii_letters)
        bid1=  a + str(customerobj.id) + str(serviceDate)
        a= bid1.replace('-', "")
      

        for i in cartobj:
            bookobj=ServiceBooking(ordernumber= a ,name=name1,phone=phone1,email=email1,vehicle_model=vehicleModel,vehicle_number=vehicle_number,service_date=serviceDate,time_slot=timeSlot,additional_info=additionalInfo,customer_id_id=customerobj.id,service_id_id= i.service_id.id,sc_id_id= i.service_id.sc_id.id )#left side model attribte
            bookobj.save() 
        

    totalbill1= 0

    for i in cartobj:
        totalbill1 = i.totalprice + totalbill1

    advnce= totalbill1*0.3
    
    o= order(ordernumber= a, totalbill= totalbill1,advanceamt= advnce)
    o.save()

    orders= order.objects.get(ordernumber= a)

    send_mail = EmailMessage('AutoServices','Your Service Booking Successfully Thank You!',to=['sakshikulade@gmail.com'])
    send_mail.send()
    
     
    return render(request,"payment.html",{'bookobj':bookobj,'cartobj':orders.advanceamt,'session':customerobj.firstname,'totalbill':o.totalbill})

def showbook(request):
    bookobj = ServiceBooking.objects.all()
    return render(request,'showbook.html',{'book':bookobj})


def paymentsuccess(request,tid,orderid):
    print(tid)
    usersession = request.session['username']
    customerobj = user.objects.get(email=usersession)
    bookobj = ServiceBooking.objects.filter(ordernumber = orderid)
    current_date = datetime.datetime.now()
    print(current_date)

    orderobj = order.objects.get(ordernumber = orderid)
    print(orderobj.totalbill)
    paymentobj = payment(transactionid = tid, paymentstatus='Advance Paid ',customerid=customerobj,oid = orderobj)
    paymentobj.save()
  
    send_mail = EmailMessage('thank you','Your Payment Successfully',to=['sakshikulade@gmail.com'])
    send_mail.send()
    
    return render(request,'bill.html',{"bookobj":bookobj,"cobj":customerobj,'oobj':orderobj,'current_date': current_date})

def bill(request):
    usersession = request.session['username']
    customerobj = user.objects.get(email=usersession)
    bookobj = ServiceBooking.objects.filter(customer_id = customerobj.id)
    orderobj = order.objects.get(order_id = orderobj.id)
   

    
    return render(request,'bill.html',{"bookobj":bookobj,"orderobj":orderobj})

 



    

    

    
    