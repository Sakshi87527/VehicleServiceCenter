from django.db import models

# Create your models here.

class admin(models.Model):
    GENDER =(("Male","male"),("Female","female"))
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=200)
    gender = models.CharField(max_length=200,choices=GENDER)

    class meta:
        db_table='admin'



class user(models.Model):
    GENDER =(("Male","male"),("Female","female"))
    firstname = models.CharField(max_length=100)
    lastname = models.CharField(max_length=100)
    email = models.EmailField()
    password = models.CharField(max_length=200)
    gender = models.CharField(max_length=200,choices=GENDER)

    class meta:
        db_table="customer"
        
class servicecenter(models.Model):
   sc_name= models.CharField(max_length=200)
   sc_email= models.EmailField()
   sc_phone= models.BigIntegerField()
   sc_address= models.CharField(max_length=200)

   class meta:
       db_table="servicecenter"
class custommanager(models.Manager):
    def get_vehicle_service(self):
        return super().get_queryset().filter(name ='Car Service Center')
    
class s_center(models.Model):
   owner = models.ForeignKey(admin,on_delete=models.CASCADE)
   name = models.CharField(max_length=200)
   email = models.EmailField(max_length=200)
   phone = models.BigIntegerField()
   state = models.CharField(max_length=200)
   city = models.CharField(max_length=200)
   center_name=models.CharField(max_length=200)
   center_add = models.CharField(max_length=200)
   center_phone = models.BigIntegerField()
   image = models.ImageField(upload_to="media")

   vehicles = custommanager()

   class meta:
       db_table="center"
    
class services(models.Model):
    SELECT_CAR= [
        ('hyundai', 'Hyundai'),
        ('honda', 'Honda'),
        ('kia', 'Kia'),
        ('toyoto', 'Toyoto'),
    ]
    SERVICE_CATEGORY = [
        ('periodic service','Periodic Service'),
        ('ac service','AC Service'),
        ('batteries','Batteries'),
        ('tyres & wheel care', 'Tyres & Wheel Care'),
        ('car denting & painting','Car Denting & Painting'),
        ('car wash & detailing','Car Wash & Detailing')
    ]
    sc_id= models.ForeignKey(s_center,on_delete=models.CASCADE)
    select_car = models.CharField(max_length=20, choices=SELECT_CAR, default='0')
    service_category = models.CharField(max_length=500, choices=SERVICE_CATEGORY, default='0')
    price = models.FloatField()
    package_name = models.CharField(max_length=200)
    photo = models.ImageField(upload_to="media")
    description = models.CharField(max_length=200)

    class meta:
        db_table= "services"

class cart(models.Model):
    sc_id= models.ForeignKey(s_center,on_delete=models.CASCADE)
    service_id= models.ForeignKey(services,on_delete=models.CASCADE)
    customer_id = models.ForeignKey(user,on_delete=models.CASCADE)
    totalprice = models.FloatField()

    class Meta:
        db_table = "cart"

class ServiceBooking(models.Model): #orderdetails

    ordernumber= models.CharField(max_length= 200, default= "")
    sc_id = models.ForeignKey(s_center,on_delete=models.CASCADE)
    service_id= models.ForeignKey(services,on_delete=models.CASCADE)
    customer_id = models.ForeignKey(user,on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    vehicle_model = models.CharField(max_length=50)
    vehicle_number= models.CharField(max_length=200,default='0')
    created_at = models.DateTimeField(auto_now=True)
    service_date = models.DateField()
    time_slot = models.CharField(max_length=200)
    additional_info = models.TextField(null=True)



    class meta:
        db_table = "servicebooking"


class order(models.Model):
    ordernumber= models.CharField(default= 0, max_length= 200)
    totalbill = models.FloatField(default=0)
    advanceamt= models.FloatField(default=0)
    class Meta:
        db_table= "order"


class payment(models.Model):
    customerid = models.ForeignKey(user,on_delete = models.CASCADE)
    oid = models.ForeignKey(order,on_delete=models.CASCADE)
    paymentstatus = models.CharField(max_length=200, default='pending')
    transactionid = models.CharField(max_length=200)
    paymentmode = models.CharField(max_length=100,default='paypal')

    class meta:
        db_table = 'payment'





