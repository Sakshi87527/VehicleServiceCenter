"""
URL configuration for vehicleproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from vehicleapp import views
from vehicleapp.views import show,createview,delete,update,CenterListView,ServiceListView
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('nav/',views.index,name='nav'),
    path('thankyou/',views.thankyou,name='thankyou'),
    path('homepage/',CenterListView.as_view(),name='homepage'),
    path('contactus/',views.contactus,name='contactus'),
    path('aboutus/',views.aboutus,name='aboutus'),
    path('search/',views.search,name='search'),
    path('searchdet/',views.searchcar,name='searchdet'),
    path('vehicledetail/<int:id>/',views.vehicledetail,name='vehicledetail'),
    path('services/<int:pk>/',ServiceListView.as_view(),name="servi"),
    path('adminregister/',views.adminregisteration,name="adminregister"),
    path('adminlogin/',views.adminlogin,name="adminlogin"),
    path('userregister/',views.userregisteration,name="userregister"),
    path('userlogin/',views.userlogin,name='userlogin'),
    path('createview/',createview.as_view()),
    path('show/',show.as_view(), name="center"),
    path('delete/<int:id>',views.delete,name="delete"),
    path("edit/<int:id>",views.edit,name="edit"),
    path('update/<int:id>',views.update,name="update"),
    path('center_services/<int:id>/', views.center_services, name='center_services'),
    path('addtocart/',views.addservices,name="atc"),
    path('viewcart/',views.viewcart,name="vc"),
    path('deletecart/',views.deletecart,name='deletecart'), 
    path('summary/',views.summarypage,name="summary"),
    path('payment/',views.payments,name="payment"),
    path('booking/',views.booking,name='booking'),
    path('logout/',views.logout,name="logout"),
    path('centerprofile/',views.s_profile,name="centerprofile"),
    path('service/',views.servicess,name='service'),
    path('showbook/',views.showbook,name='showbook'),
    path('paymentsuccess/<str:tid>/<str:orderid>/',views.paymentsuccess,name='paymentsuccess'),
    path('bill/',views.bill,name="bill"),
    path('adminservice',views.adminservice,name="adminservice"),
    path('admincenter/',views.admincenter,name="admincenter")
   
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)